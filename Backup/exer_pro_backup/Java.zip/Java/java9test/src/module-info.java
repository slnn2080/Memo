module java9test {
  exports com.sam.bean;
}