package com.sam.reflect;

public interface MyInterface {
  void info();
}
