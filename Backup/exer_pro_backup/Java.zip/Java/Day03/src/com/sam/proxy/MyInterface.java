package com.sam.proxy;

@FunctionalInterface
public interface MyInterface {
  void method();
}
