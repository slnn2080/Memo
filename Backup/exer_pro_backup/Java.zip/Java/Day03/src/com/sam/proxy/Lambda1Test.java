package com.sam.proxy;

import org.junit.Test;

import java.util.function.Consumer;

public class Lambda1Test {

  @Test
  public void test1() {

  }
}
