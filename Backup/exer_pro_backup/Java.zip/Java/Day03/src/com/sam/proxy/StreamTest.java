package com.sam.proxy;

import org.junit.Test;

public class StreamTest {
  @Test
  public void test() {

  }
}
