module Day06 {
  requires java9test;
  requires junit;

  exports com.sam.references;
}