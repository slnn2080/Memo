package com.sam.references;
import com.sam.bean.Person;

public class ModuleTest {
  public static void main(String[] args) {
    Person person = new Person("sam", 12);
  }
}
