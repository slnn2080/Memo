package com.sam.exer3;

import org.junit.Test;

import java.io.IOException;

public class FileTest {


  @Test
  public void test() throws IOException {

    

  }
}
