package com.sam.exer;

import org.junit.Test;

public class Demo2 {
  @Test
  public void test() {


  }
}
