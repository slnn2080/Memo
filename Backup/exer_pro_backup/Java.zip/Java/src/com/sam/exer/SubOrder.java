package com.sam.exer;

public class SubOrder<T> extends Order<T> {

}
