package com.sam.exer;

// 此类就对应数据库中Customer表 表中添加一条记录就是造这个类的一个对象
// 然后我们创建一个CustomerDAO类 DAO是一些通用的增删改查的方法 我们在提供一个CustomerDAO类用于专门操作Customer表的
public class Customer {
  // 里面的属性可以参照表中的字段来造属性
}
